/************** ECE2049 DEMO CODE ******************/
/**************  20 August 2016   ******************/
/***************************************************/

#include <msp430.h>
#include "peripherals.h"

// Function prototypes

struct Notes{
		char pitch;
		int duration;
};

void countDown(void);
void swDelay(long int n);
void BuzzerOnPitch(char pitch);
void playNote(struct Notes song);
void configTA2(void);
void letsShred(void);

void main(void){
	WDTCTL = WDTPW | WDTHOLD;		// Stop watchdog timer

    // Config
    initLeds();
    configDisplay();
    configKeypad();
    configTA2();

    // Declare variables
    char state = 0;


    GrClearDisplay(&g_sContext); // Clear the display

      	while(1){
      		char curr_key = getKey();
      		if(curr_key == '*'){
      			state = 1;
      		}

      		switch (state){
      		case 0: // Welcome screen
      			// Write some text to the display
      		  	GrStringDrawCentered(&g_sContext, "MSP430 HERO", AUTO_STRING_LENGTH, 48, 48, TRANSPARENT_TEXT);
      		  	GrStringDrawCentered(&g_sContext, "Press * to Play", AUTO_STRING_LENGTH, 48, 64, TRANSPARENT_TEXT);
      		  	GrFlush(&g_sContext);
      		  	break;
      		case 1:
      			countDown();
      			letsShred();
      			BuzzerOff();
      			state = 0;
      			break;

      		}
      	}
}

void countDown(void){
	long int delay = 40000;

	GrClearDisplay(&g_sContext);
	GrStringDrawCentered(&g_sContext, "3", AUTO_STRING_LENGTH, 48, 48, TRANSPARENT_TEXT);
	GrFlush(&g_sContext);
	setLeds(BIT3);
	BuzzerOnPitch(66);
	swDelay(delay);

	GrClearDisplay(&g_sContext);
	GrStringDrawCentered(&g_sContext, "2", AUTO_STRING_LENGTH, 48, 48, TRANSPARENT_TEXT);
	BuzzerOff();
	BuzzerOnPitch(66);
	GrFlush(&g_sContext);
	setLeds(BIT2);
	swDelay(delay);

	GrClearDisplay(&g_sContext);
	GrStringDrawCentered(&g_sContext, "1", AUTO_STRING_LENGTH, 48, 48, TRANSPARENT_TEXT);
	BuzzerOff();
	BuzzerOnPitch(66);
	GrFlush(&g_sContext);
	setLeds(BIT1);
	swDelay(delay);

	GrClearDisplay(&g_sContext);
	GrStringDrawCentered(&g_sContext, "GO", AUTO_STRING_LENGTH, 48, 48, TRANSPARENT_TEXT);
	BuzzerOff();
	BuzzerOnPitch(63);
	GrFlush(&g_sContext);
	setLeds(0x0F);
	swDelay(delay);

	GrClearDisplay(&g_sContext);
	BuzzerOff();

	setLeds(0x00);
}

void swDelay(long int n){
	long int i;
	for (i = 0; i< n; i++){}
}

void BuzzerOnPitch(char pitch)
{
	// Initialize PWM output on P3.5, which corresponds to TB0.5
	P3SEL |= BIT5; // Select peripheral output mode for P3.5
	P3DIR |= BIT5;

	TB0CTL  = (TBSSEL__ACLK|ID__1|MC__UP);  // Configure Timer B0 to use ACLK, divide by 1, up mode
	TB0CTL  &= ~TBIE; 						// Explicitly Disable timer interrupts for safety

	// Now configure the timer period, which controls the PWM period
	// Doing this with a hard coded values is NOT the best method
	// We do it here only as an example. You will fix this in Lab 2.
	TB0CCR0   = pitch; 					// Set the PWM period in ACLK ticks, original 128
	TB0CCTL0 &= ~CCIE;					// Disable timer interrupts

	// Configure CC register 5, which is connected to our PWM pin TB0.5
	TB0CCTL5  = OUTMOD_7;					// Set/reset mode for PWM
	TB0CCTL5 &= ~CCIE;						// Disable capture/compare interrupts
	TB0CCR5   = TB0CCR0/2; 					// Configure a 50% duty cycle
}

void letsShred(void){

	char D = 56;
	char E = 50;
	char G = 42;
	char F = 47;
	char A = 37;
	char D_hi = 32;
	char B_hi = 35;
	char C_hi = 34;

	struct Notes song1[25];
	char pitch_arr_song1[] = {D, D, E, D, G, F, D, D ,E, D, A, G, D, D, D_hi, B_hi, G, F, E, C_hi, C_hi, B_hi, G, A, G};
	int dur_arr_song1[] = {1, 1, 2, 2, 2, 4, 1, 1, 2, 2, 2, 4, 1, 1, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 4};
	int i;

	for ( i = 0; i < 25; i++){
		song1[i].pitch = pitch_arr_song1[i];
		song1[i].duration = dur_arr_song1[i];
	}

	// State machine to detect '#' here

	// Test playing song:
	for(i = 0; i < 25; i++){
		playNote(song1[i]);
	}

}

void playNote(struct Notes song){
	BuzzerOnPitch(song.pitch);
	int counter = 0;
	while(1){
		if(!TA2CTL){
			counter++; // counter == 2186 is 1 second
		}
		if(counter == song.duration * 2186){
			BuzzerOff();
			break;
		}
	}
}

void configTA2(void){
	TA2CTL  = (TASSEL__ACLK|ID__1|MC__UP);  // Configure Timer A2 to use ACLK, divide by 1, up mode
	TA2CTL  &= ~TAIE; 						// Explicitly Disable timer interrupts for safety
}
